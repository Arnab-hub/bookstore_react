import React from 'react'

const UserTable = props => (
  <table>
    <thead>
      <tr>
        <th>Title</th>
        <th>Author</th>
        <th>ISBN</th>
        <th>Publication Date</th>
        <th>Publisher</th>
        <th>Price</th>
        <th>Genre</th>
        <th>Format</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (props.users.map(user => (
          <tr key={user.id}>
            <td>{user.name}</td>
            <td>{user.username}</td>
            <td>{user.isbn}</td>
            <td>{user.date}</td>
            <td>{user.pub}</td>
            <td>{user.price}</td>
            <td>{user.genre}</td>
            <td>{user.format}</td>


            <td>
              <button
                onClick={() => {
                  props.editRow(user)
                }}
                className="button muted-button"
              >
                Edit
              </button>
              <button
                onClick={() => props.deleteUser(user.id)}
                className="button muted-button"
              >
                Delete
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={4}>Empty Store</td>
        </tr>
      )}
    </tbody>
  </table>
)

export default UserTable
