import React, { useState } from 'react'

const AddUserForm = props => {
	const initialFormState = { id: null, name: '', username: '', isbn: '', date:'',
	 pub: '', genre: '', format:'' }
	const [ user, setUser ] = useState(initialFormState)

	const handleInputChange = event => {
		const { name, value } = event.target

		setUser({ ...user, [name]: value })
	}

	return (
		<form
			onSubmit={event => {
				event.preventDefault()
				if (!user.name || !user.username || !user.isbn || !user.pub || !user.pub || !user.price || !user.genre || !user.format) 
				return

				props.addUser(user)
				setUser(initialFormState)
			}}
		>
			<label>Title</label>
			<input type="text" name="name" value={user.name} onChange={handleInputChange} />
			<label>Author</label>
			<input type="text" name="username" value={user.username} onChange={handleInputChange} />
			<label>ISBN</label>
			<input type="tel" name="isbn" value={user.isbn} onChange={handleInputChange} />
			<label>Publication Date</label>
			<input type="date" name="date" value={user.date} onChange={handleInputChange} />
			<label>Publisher</label>
			<input type="text" name="pub" value={user.pub} onChange={handleInputChange} />
			<label>Price</label>
			<input type="number" name="price" value={user.price} onChange={handleInputChange} />
			<label>Genre</label>
			<select name="genre" value={user.genre} onChange={handleInputChange}>
  <option value="Select">Select</option>
  <option value="Fantasy">Fantasy</option>
  <option value="Thriller">Thriller</option>
  <option value="Science Fiction">Science Fiction</option>
  <option value="Biography">Biography</option>
  <option value="Horror">Horror</option>
</select>
<label>Format</label>
	<select name="format" value={user.format} onChange={handleInputChange}>
  <option value="Select">Select</option>
  <option value="Hardcover">Hardcover</option>
  <option value="Paperback">Paperback</option>
  <option value="E-Book">E-Book</option>
  </select>
			<button>Add new book</button>
		</form>
	)
}

export default AddUserForm
